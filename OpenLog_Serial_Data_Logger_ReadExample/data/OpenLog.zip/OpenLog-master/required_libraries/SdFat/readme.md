SdFatlib-beta is a library from [Bill Greiman�s github](https://github.com/greiman/SdFat-beta). 

OpenLog currently uses the commit from [July 19 2015](https://github.com/greiman/SdFat-beta/commit/7016042d22ec9e4a3fe93565bfff1d61fb8271e2).

For more information about installing Arduino libraries see the [SparkFun Learn tutorial](https://learn.sparkfun.com/tutorials/installing-an-arduino-library).